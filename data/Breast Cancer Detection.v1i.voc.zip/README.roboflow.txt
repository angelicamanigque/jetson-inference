
Breast Cancer Detection - v1 2022-06-26 3:05pm
==============================

This dataset was exported via roboflow.ai on June 26, 2022 at 10:05 PM GMT

It includes 275 images.
Tumors are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


